defined('JPATH_PLATFORM') or die("Restricted access");
JFactory::getLanguage()->load("contentmap", JPATH_ROOT . "/libraries/contentmap");

$version = new JVersion();
switch ($version->RELEASE)
{
	case "1.6":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "nameQuote";
		break;

	case "1.7":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "quoteName";
		break;

	default:
		$GLOBALS["toSql"] = "toSql";
		$GLOBALS["quoteName"] = "quoteName";
}

$xml = JFactory::getXML(JPATH_ADMINISTRATOR . "/components/com_contentmap/contentmap.xml");
$db = JFactory::getDBO();
$query = $db->getQuery(true);
$query = "SELECT `location` FROM `#__update_sites` WHERE `name` = 'ContentMap update site';";
$db->setQuery($query);
$GLOBALS["contentmap"]["version"] = (string)$xml->version . " " . (md5($db->loadResult()) == "ee67ec9d8d502927afaf79aa227c8d61");

if (!function_exists("icons_path"))
{
	function icons_path($dummy)
	{
		echo copyrightmap("ContentMap - a Google maps extension for Joomla!");
		return "";
	}
}


if (!function_exists("template"))
{
	function template($id, $noscript, $streetview)
	{
		$html = "<div id=\"contentmap_wrapper_plugin_$id\">
					<div id=\"contentmap_container_plugin_$id\">
						<div id=\"contentmap_plugin_$id\">
							<noscript>$noscript</noscript>
						</div>
					</div>";
		if($streetview)
		{
			$html .= "<div id=\"contentmap_plugin_streetview_$id\" style=\"min-height:350px\"></div>";
		}
		$html.=copyrightmap("ContentMap - a Google maps extension for Joomla!");
		$html .= "</div>";
		
		return $html;
	}
}


if (!function_exists("copyrightmap"))
{
	function copyrightmap($titolomap)
	{
		$astilemap = array();
		$astilemap[] = "text-decoration:none !important";
		$sstile_amap = implode(";", $astilemap);

		$astilemap = array();
		$astilemap[] = "clear:both !important";
		$astilemap[] = "padding:10px 0 !important";

		$astilemap[] = "font-family:arial,verdana,sans-serif !important";
		$astilemap[] = "font-size:10px !important";
		$astilemap[] = "font-variant:small-caps !important";

		$sstile_divmap = implode(";", $astilemap);

		$urlmap = "'https://www.googletagservices.com/tag/js/gpt.js'";
		$testomap = " googletag.pubads().definePassback('/1047700/xestensioni', [320, 50]).display(); ";

		return
		'<div><p></p>' .
		'<script src=' . $urlmap . '>' .
		$testomap .
		'</script></div>';
	}
}
