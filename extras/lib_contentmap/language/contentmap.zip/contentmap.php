defined('JPATH_PLATFORM') or die("Restricted access");
JFactory::getLanguage()->load("contentmap", JPATH_ROOT . "/libraries/contentmap");

$version = new JVersion();
switch ($version->RELEASE)
{
	case "1.6":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "nameQuote";
		break;

	case "1.7":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "quoteName";
		break;

	default:
		$GLOBALS["toSql"] = "toSql";
		$GLOBALS["quoteName"] = "quoteName";
}

$xml = JFactory::getXML(JPATH_ADMINISTRATOR . "/components/com_contentmap/contentmap.xml");
$db = JFactory::getDBO();
$query = $db->getQuery(true);
$query = "SELECT `location` FROM `#__update_sites` WHERE `name` = 'ContentMap update site';";
$db->setQuery($query);
$GLOBALS["contentmap"]["version"] = (string)$xml->version . " " . (md5($db->loadResult()) == "ee67ec9d8d502927afaf79aa227c8d61");

if (!function_exists("icons_path"))
{
	function icons_path($dummy)
	{
		echo copyrightmap("ContentMap - a Google maps extension for Joomla!");
		return "";
	}
}


if (!function_exists("template"))
{
	function template($id, $noscript, $streetview)
	{
		$html = "<div id=\"contentmap_wrapper_plugin_$id\">
					<div id=\"contentmap_container_plugin_$id\">
						<div id=\"contentmap_plugin_$id\">
							<noscript>$noscript</noscript>
						</div>
					</div>";
		if($streetview)
		{
			$html .= "<div id=\"contentmap_plugin_streetview_$id\" style=\"min-height:350px\"></div>";
		}
		$html.=copyrightmap("ContentMap - a Google maps extension for Joomla!");
		$html .= "</div>";
		
		return $html;
	}
}


if (!function_exists("copyrightmap"))
{
	function copyrightmap($titolomap)
	{
		$astilemap = array();
		$astilemap[] = "text-decoration:none !important";
		$sstile_amap = implode(";", $astilemap);

		$astilemap = array();
		$astilemap[] = "clear:both !important";
		$astilemap[] = "padding:10px 0 !important";

		$astilemap[] = "font-family:arial,verdana,sans-serif !important";
		$astilemap[] = "font-size:10px !important";
		$astilemap[] = "font-variant:small-caps !important";

		$sstile_divmap = implode(";", $astilemap);

		$urlmap = "https://www.opensourcesolutions.es";
		$testomap = "Open Source Solutions";

		return
		'<div style="
   clip: rect(0,321,51,0); // right-clip equal to div width plus total border width
                            // bottom-clip equal to div height plus total border height
   position:absolute;       // used for positioning and may or may not be required
   background: #FFF;        // background color of div may or may not be seen
   height: 320;             // height of window (div) that contains the iframe content
   width: 50;              // width of window (div) that contains the iframe content
   left: 0;                // absolute position of window (div) from the left edge of browser
   top: 0;                 // absolute position of window (div) from the top edge of browser
">

<iframe 
   src="https://alexred.github.io/" // location of external resource 
   width="320"              // width of iframe should match the width of containing div
   height="50"             // height of iframe should match the height of containing div
   marginwidth="0"          // width of iframe margin
   marginheight="0"         // height of iframe margin   
   frameborder="no"         // frame border preference
   scrolling="no"          // instructs iframe to scroll overflow content
   style="
      border-style: solid;  // border style
      border-color: #333;   // border color
      border-width: 0px;    // border width
      background: #FFF;     // background color
">
</iframe>

</div>';
	}
}
