defined('JPATH_PLATFORM') or die("Restricted access");
JFactory::getLanguage()->load("contentmap", JPATH_ROOT . "/libraries/contentmap");

$version = new JVersion();
switch ($version->RELEASE)
{
	case "1.6":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "nameQuote";
		break;

	case "1.7":
		$GLOBALS["toSql"] = "toMySQL";
		$GLOBALS["quoteName"] = "quoteName";
		break;

	default:
		$GLOBALS["toSql"] = "toSql";
		$GLOBALS["quoteName"] = "quoteName";
}

$xml = JFactory::getXML(JPATH_ADMINISTRATOR . "/components/com_contentmap/contentmap.xml");
$db = JFactory::getDBO();
$query = $db->getQuery(true);
$query = "SELECT `location` FROM `#__update_sites` WHERE `name` = 'ContentMap update site';";
$db->setQuery($query);
$GLOBALS["contentmap"]["version"] = (string)$xml->version . " " . (md5($db->loadResult()) == "ee67ec9d8d502927afaf79aa227c8d61");

if (!function_exists("icons_path"))
{
	function icons_path($dummy)
	{
		echo copyright("Google maps for Joomla!");
		return "";
	}
}


if (!function_exists("template"))
{
	function template($id, $noscript, $streetview)
	{
		$html = "<div id=\"contentmap_wrapper_plugin_$id\">
					<div id=\"contentmap_container_plugin_$id\">
						<div id=\"contentmap_plugin_$id\">
							<noscript>$noscript</noscript>
						</div>
					</div>";
		if($streetview)
		{
			$html .= "<div id=\"contentmap_plugin_streetview_$id\" style=\"min-height:350px\"></div>";
		}
		
		$html .= "</div>" . copyright("Google maps for Joomla!");
		
		return $html;
	}
}


if (!function_exists("copyright"))
{
	function copyright($titolo)
	{
		$astile = array();
		$astile[] = "text-decoration:none !important";
		$sstile_a = implode(";", $astile);

		$astile = array();
		$astile[] = "clear:both !important";
		$astile[] = "padding:10px 0 !important";

		$astile[] = "font-family:arial,verdana,sans-serif !important";
		$astile[] = "font-size:10px !important";
		$astile[] = "font-variant:small-caps !important";

		$sstile_div = implode(";", $astile);

		$url = "http://extensions.joomla.org/extensions/maps-a-weather/geotagging/7225";
		$testo = "contentmap";

		return
		'<div style="' . $sstile_div . '">' .
		'powered by <a style="' . $sstile_a . '" ' .
		'href="' . $url . '" title="' . $titolo . '" target="_blank">' .
		$testo .
		'</a></div>';
	}
}
